package com.test;

import java.util.HashSet;
import java.util.Set;

public class Test2 {
	public static void main(String[] args) {

		String s = "1234";
		System.out.println(s.hashCode());
		
		Integer integer = new Integer(1509442);
		System.out.println(integer.hashCode());
		
		
	
	}

}
