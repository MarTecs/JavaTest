package com.test;

import java.util.ArrayList;
import java.util.Vector;

public class Test6 {

	public static void main(String[] args) {
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("aa");
		Vector<String> strings = new Vector<String>();
		strings.add("aa");
			

	}

}
