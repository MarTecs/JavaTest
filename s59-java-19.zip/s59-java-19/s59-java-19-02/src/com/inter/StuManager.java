package com.inter;

public interface StuManager {
	
	public void add();
	public void del();

}
