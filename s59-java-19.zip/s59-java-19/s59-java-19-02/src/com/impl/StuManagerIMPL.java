package com.impl;

import com.inter.StuManager;

public class StuManagerIMPL implements StuManager {

	@Override
	public void add() {
		System.out.println("����");

	}

	@Override
	public void del() {
		System.out.println("ɾ��");

	}

}
